package com.multilink.app.ui.theme

import androidx.compose.ui.graphics.Color

val NavyBg = Color(0xFF0B1420)
val NavyCard = Color(0xFF101E36)
val NavyCard2 = Color(0xFF16294A)
val ElectricBlue = Color(0xFF1E6FE0)
val Cyan = Color(0xFF22D3EE)
val TextDim = Color(0xFFAEBEDD)
val TextDimmer = Color(0xFF6E7EA3)
