package com.multilink.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import androidx.compose.runtime.mutableStateListOf

/**
 * Wraps Android's public BLE APIs to scan for, and hold connections to,
 * multiple peripherals at once.
 *
 * Real behavior:
 *  - startScan()/stopScan() use the real BluetoothLeScanner.
 *  - connect() opens an *additional* BluetoothGatt client per device without
 *    closing any existing connection — so yes, this genuinely holds several
 *    devices connected simultaneously, which is the core MultiLink idea.
 *
 * Real limits (not solvable from app code):
 *  - The practical ceiling on simultaneous LE connections (commonly ~4-7)
 *    is set by the phone's Bluetooth chipset/firmware. There is no public
 *    Android API to raise it.
 *  - This class only talks BLE (GATT). Classic audio profiles (A2DP media,
 *    HFP calls) are owned by the OS's own Bluetooth/telecom stack on stock
 *    Android — a third-party app cannot become the system audio router
 *    without a system-level (OEM) integration.
 */
@SuppressLint("MissingPermission")
class BleManager(context: Context) {

    private val appContext = context.applicationContext

    private val adapter: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    /** Backing list for the dashboard — every entry replaced immutably so Compose recomposes correctly. */
    val scanResults = mutableStateListOf<ConnectedDevice>()

    private val gattConnections = mutableMapOf<String, BluetoothGatt>()

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val updated = ConnectedDevice(
                address = device.address,
                name = device.name ?: "Unknown device",
                rssi = result.rssi,
                isConnected = gattConnections.containsKey(device.address)
            )
            val existingIndex = scanResults.indexOfFirst { it.address == device.address }
            if (existingIndex >= 0) scanResults[existingIndex] = updated else scanResults.add(updated)
        }

        override fun onScanFailed(errorCode: Int) {
            // In a fuller build, surface this via a StateFlow<String?> the UI observes.
        }
    }

    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner ?: return
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        scanner.startScan(null, settings, scanCallback)
    }

    fun stopScan() {
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
    }

    /** Opens a new GATT connection to [address] without touching any other open connection. */
    fun connect(address: String) {
        val device: BluetoothDevice = adapter?.getRemoteDevice(address) ?: return
        val gatt = device.connectGatt(appContext, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                val index = scanResults.indexOfFirst { it.address == address }
                if (index >= 0) {
                    scanResults[index] = scanResults[index].copy(
                        isConnected = newState == BluetoothProfile.STATE_CONNECTED
                    )
                }
                if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    gattConnections[address]?.close()
                    gattConnections.remove(address)
                }
            }
        })
        gattConnections[address] = gatt
    }

    fun disconnect(address: String) {
        gattConnections[address]?.let {
            it.disconnect()
            it.close()
        }
        gattConnections.remove(address)
        val index = scanResults.indexOfFirst { it.address == address }
        if (index >= 0) scanResults[index] = scanResults[index].copy(isConnected = false)
    }

    fun disconnectAll() {
        gattConnections.keys.toList().forEach { disconnect(it) }
    }

    /** How many devices this app currently holds open at once — the number the concept doc's claims hinge on. */
    fun activeConnectionCount(): Int = gattConnections.size
}
