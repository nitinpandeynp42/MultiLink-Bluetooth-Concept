package com.multilink.app.bluetooth

import com.multilink.app.data.DeviceCategory
import com.multilink.app.data.PriorityTier

/**
 * Immutable snapshot of one BLE peripheral, as shown in the dashboard.
 * Kept fully immutable (all `val`) so Compose can detect changes correctly —
 * updates go through BleManager replacing the list entry via `.copy()`.
 */
data class ConnectedDevice(
    val address: String,
    val name: String,
    val category: DeviceCategory = DeviceCategory.UNKNOWN,
    val rssi: Int = 0,
    val isConnected: Boolean = false,
    val currentTier: PriorityTier = PriorityTier.NORMAL
)
