package com.multilink.app.priority

import com.multilink.app.bluetooth.ConnectedDevice
import com.multilink.app.data.DeviceCategory
import com.multilink.app.data.PriorityTier

/**
 * Rule-based priority engine.
 *
 * Scope, honestly stated: this ranks connected devices for *display and
 * app-level decisions* — e.g. which device this app treats as "primary"
 * for its own UI. It is a real, working piece of logic, but it is not the
 * HAL-level bandwidth/radio scheduler described in the MultiLink concept
 * doc. That layer sits below any normal app on stock Android and would
 * require OEM/system-level integration (see the concept doc's "OEM
 * Licensing" business model) to actually implement.
 */
class PriorityManager {

    /** Highest-priority device first; ties broken by stronger signal (RSSI closer to 0). */
    fun rank(devices: List<ConnectedDevice>): List<ConnectedDevice> =
        devices.sortedWith(
            compareByDescending<ConnectedDevice> { it.currentTier.weight }
                .thenByDescending { it.rssi }
        )

    /** Simple context-aware tier assignment — the seed of a "smart" engine, not a trained model. */
    fun tierFor(category: DeviceCategory, isInActiveCall: Boolean, isGaming: Boolean): PriorityTier =
        when {
            isInActiveCall && category == DeviceCategory.EARBUDS -> PriorityTier.CRITICAL
            isGaming && category == DeviceCategory.GAME_CONTROLLER -> PriorityTier.CRITICAL
            category == DeviceCategory.EARBUDS || category == DeviceCategory.SPEAKER -> PriorityTier.HIGH
            category == DeviceCategory.KEYBOARD || category == DeviceCategory.MOUSE -> PriorityTier.NORMAL
            else -> PriorityTier.LOW
        }
}
