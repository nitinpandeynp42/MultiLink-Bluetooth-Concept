package com.multilink.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.multilink.app.bluetooth.ConnectedDevice
import com.multilink.app.ui.theme.Cyan
import com.multilink.app.ui.theme.ElectricBlue
import com.multilink.app.ui.theme.NavyBg
import com.multilink.app.ui.theme.TextDim

@Composable
fun DashboardScreen(
    devices: List<ConnectedDevice>,
    isScanning: Boolean,
    onScanToggle: () -> Unit,
    onConnect: (String) -> Unit,
    onDisconnect: (String) -> Unit,
) {
    val connectedCount = devices.count { it.isConnected }

    Scaffold(
        containerColor = NavyBg,
        topBar = {
            TopAppBar(
                title = { Text("MultiLink", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyBg)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Text("Connect Everything. Simultaneously.", color = ElectricBlue, fontSize = 14.sp)
            Spacer(Modifier.height(20.dp))

            Button(
                onClick = onScanToggle,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
            ) {
                Text(if (isScanning) "Stop Scan" else "Scan for Devices")
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "$connectedCount connected simultaneously · ${devices.size} nearby",
                color = Cyan,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))

            if (devices.isEmpty()) {
                Text(
                    "No devices found yet. Tap Scan, and make sure a nearby BLE accessory is powered on and advertising.",
                    color = TextDim,
                    fontSize = 13.sp
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(devices, key = { it.address }) { device ->
                        DeviceCard(
                            device = device,
                            onConnect = { onConnect(device.address) },
                            onDisconnect = { onDisconnect(device.address) }
                        )
                    }
                }
            }
        }
    }
}
