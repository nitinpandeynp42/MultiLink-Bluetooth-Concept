package com.multilink.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Modifier
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.multilink.app.bluetooth.ConnectedDevice
import com.multilink.app.ui.theme.Cyan
import com.multilink.app.ui.theme.ElectricBlue
import com.multilink.app.ui.theme.NavyCard
import com.multilink.app.ui.theme.TextDim
import com.multilink.app.ui.theme.TextDimmer

@Composable
fun DeviceCard(
    device: ConnectedDevice,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(NavyCard, RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(device.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(4.dp))
            Text("${device.address} · RSSI ${device.rssi} dBm", color = TextDimmer, fontSize = 11.sp)
            Spacer(Modifier.height(2.dp))
            Text(
                text = if (device.isConnected) "Connected · ${device.currentTier}" else "Not connected",
                color = if (device.isConnected) Cyan else TextDim,
                fontSize = 12.sp
            )
        }
        Button(
            onClick = if (device.isConnected) onDisconnect else onConnect,
            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
        ) {
            Text(if (device.isConnected) "Disconnect" else "Connect")
        }
    }
}
