package com.multilink.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.multilink.app.ui.DashboardScreen
import com.multilink.app.ui.theme.MultiLinkTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MultiLinkViewModel by viewModels()

    // Permission results aren't branched on here — if any are denied, tapping
    // "Scan" again simply won't find devices, which is enough for this MVP.
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val neededPermissions = mutableListOf<String>().apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_SCAN)
                add(Manifest.permission.BLUETOOTH_CONNECT)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
        permissionLauncher.launch(neededPermissions.toTypedArray())

        setContent {
            var isScanning by remember { mutableStateOf(false) }

            MultiLinkTheme {
                DashboardScreen(
                    devices = viewModel.devices,
                    isScanning = isScanning,
                    onScanToggle = {
                        isScanning = !isScanning
                        if (isScanning) viewModel.startScan() else viewModel.stopScan()
                    },
                    onConnect = { address -> viewModel.connect(address) },
                    onDisconnect = { address -> viewModel.disconnect(address) }
                )
            }
        }
    }

    override fun onDestroy() {
        viewModel.stopScan()
        super.onDestroy()
    }
}
