package com.multilink.app.data

/** Broad accessory categories, matching the ones in the MultiLink concept doc. */
enum class DeviceCategory {
    EARBUDS, SPEAKER, SMARTWATCH, LAPTOP, TABLET, TV,
    KEYBOARD, MOUSE, CAR, GAME_CONTROLLER, PRINTER, CAMERA,
    SMART_HOME, UNKNOWN
}

/**
 * App-level scheduling priority. This ranks devices for *this app's own
 * decisions* (what to show first, which device to request audio focus for).
 * It does not — and on stock, non-rooted Android cannot — change how the
 * OS Bluetooth stack itself allocates radio time between devices.
 */
enum class PriorityTier(val weight: Int) {
    CRITICAL(100), // e.g. active call audio
    HIGH(75),      // e.g. media playback, active game controller
    NORMAL(50),    // e.g. keyboard, mouse
    LOW(25)        // e.g. idle background devices
}

data class DeviceProfile(
    val address: String,
    val name: String,
    val category: DeviceCategory = DeviceCategory.UNKNOWN,
    val preferredTier: PriorityTier = PriorityTier.NORMAL
)
