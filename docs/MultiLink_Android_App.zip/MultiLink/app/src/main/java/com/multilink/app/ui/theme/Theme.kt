package com.multilink.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MultiLinkColorScheme = darkColorScheme(
    background = NavyBg,
    surface = NavyCard,
    primary = ElectricBlue,
    secondary = Cyan,
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun MultiLinkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MultiLinkColorScheme,
        content = content
    )
}
