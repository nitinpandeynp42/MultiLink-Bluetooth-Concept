package com.multilink.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.multilink.app.bluetooth.BleManager
import com.multilink.app.bluetooth.ConnectedDevice
import com.multilink.app.priority.PriorityManager

class MultiLinkViewModel(application: Application) : AndroidViewModel(application) {

    private val bleManager = BleManager(application)
    private val priorityManager = PriorityManager()

    /** Compose-observable list — same instance BleManager mutates. */
    val devices get() = bleManager.scanResults

    fun startScan() = bleManager.startScan()
    fun stopScan() = bleManager.stopScan()
    fun connect(address: String) = bleManager.connect(address)
    fun disconnect(address: String) = bleManager.disconnect(address)

    fun rankedDevices(): List<ConnectedDevice> = priorityManager.rank(devices)

    fun activeConnectionCount(): Int = bleManager.activeConnectionCount()

    override fun onCleared() {
        bleManager.disconnectAll()
        super.onCleared()
    }
}
