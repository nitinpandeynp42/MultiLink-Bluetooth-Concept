# MultiLink — Android MVP

This is a real, working Android Studio project (Kotlin + Jetpack Compose), not a mockup.
It implements the subset of the MultiLink concept that is actually achievable with
Android's public APIs. Please read the **Scope & Limitations** section before opening
an issue about a missing feature from the original concept doc — most gaps there are
intentional and explained below.

## What this app actually does

- **Real BLE scanning** — `BleManager` uses `BluetoothLeScanner` to discover nearby
  Bluetooth Low Energy devices.
- **Real multi-device connections** — tapping "Connect" on more than one device opens
  a separate `BluetoothGatt` client per device, without dropping the others. This is
  the literal, working version of "connect to multiple devices simultaneously."
- **A rule-based priority engine** — `PriorityManager` ranks connected devices by a
  simple weighted tier system (Critical / High / Normal / Low) and signal strength.
  It's real logic, but it's rules, not a trained AI model.
- **A dark, glassmorphism-inspired dashboard** — matches the MultiLink brand from the
  concept doc and pitch deck.

## Scope & Limitations (read this before running)

Several features in the original MultiLink concept doc require access that sits
**below** what any regular Android app — including this one — can reach on a
non-rooted, stock device:

| Concept doc feature | Why this app can't fully deliver it |
|---|---|
| Unlimited Bluetooth pairing | The BLE connection ceiling (commonly ~4–7 concurrent links) is enforced by the phone's Bluetooth chipset/firmware, not the OS. No public API raises it. |
| Dynamic bandwidth allocation | Radio time-slicing happens in the Bluetooth controller/HAL, a layer no app can access. |
| Smart audio routing across A2DP/HFP | Classic audio profile routing (which earbuds get music vs. calls) is owned by the OS's own Bluetooth/telecom stack. A third-party app cannot become the system audio router without an OEM-level system integration. |
| Auracast / LE Audio broadcast | Requires phone + accessory hardware/firmware that supports LE Audio (Android 13+ on compatible chipsets). This app doesn't add hardware capability that isn't already there. |

This is exactly why the original business plan includes **OEM licensing** — those
deeper features are a partnership/systems-integration proposition, not something a
downloadable app can ship on its own.

What's real and demoable today: scanning, holding multiple simultaneous BLE GATT
connections, and an app-level priority/dashboard layer on top of them.

## Requirements

- Android Studio (Koala or newer recommended)
- A physical Android device running Android 8.0 (API 26) or later with Bluetooth LE
  hardware — the emulator does not support real BLE scanning/connections
- One or more nearby BLE-advertising accessories to test against (earbuds, a fitness
  band, a BLE-capable smart bulb, etc.)

## Running it

1. Open the `MultiLink/` folder in Android Studio.
2. Let Gradle sync — Android Studio will offer to generate the Gradle wrapper if it's
   missing; accept that prompt (this project ships without a committed
   `gradle-wrapper.jar`, since that's a binary file).
3. Connect a physical device via USB with USB debugging enabled.
4. Run the `app` configuration.
5. On first launch, grant the Bluetooth permission prompt.
6. Tap **Scan for Devices**, then **Connect** on more than one nearby device to see
   simultaneous connections hold at once.

## Project layout

```
app/src/main/java/com/multilink/app/
├── MainActivity.kt              # permission request + Compose host
├── MultiLinkViewModel.kt        # wires BleManager + PriorityManager to the UI
├── bluetooth/
│   ├── BleManager.kt            # real scanning + multi-GATT connection logic
│   └── ConnectedDevice.kt       # immutable UI state model
├── data/
│   └── DeviceProfile.kt         # device categories & priority tiers
├── priority/
│   └── PriorityManager.kt       # rule-based ranking engine
└── ui/
    ├── DashboardScreen.kt
    ├── DeviceCard.kt
    └── theme/                   # MultiLink dark/blue-neon brand colors
```

## Suggested next steps

- Persist `DeviceProfile` per device (Room database) so priority preferences survive restarts.
- Add a `Context-Aware Automation` layer using `ActivityRecognitionClient` to
  auto-trigger scans on arrival at known locations.
- Move `PriorityManager`'s rules into a small on-device model once there's real usage
  data to train on — the current version is intentionally simple and explainable.
